<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>2017 Journal Citation Reports for ACS</title>
<link rel="stylesheet" href="css/style.css">
<!--<link rel="stylesheet" href="assets/css/style.css">-->
 <!-- Google Analytics -->
        <script>
            (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
            })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

            ga('create', 'UA-7663985-43', 'auto');
            ga('send', 'pageview');
        </script>
        
        <!-- Hotjar Tracking Code for https://axial.acs.org/ -->
        <script>
          (function(h,o,t,j,a,r){
          h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
          h._hjSettings={hjid:1265450,hjsv:6};
          a=o.getElementsByTagName('head')[0];
          r=o.createElement('script');r.async=1;
          r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
          a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
      </script>
        
        <script type="text/javascript">     
          var _sf_async_config = _sf_async_config || {};      
          _sf_async_config.uid = 61642;     
          _sf_async_config.domain = "axial.acs.org"; 
          var _sf_startpt = (new Date()).getTime(); 
         </script> 

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<script id="jcrJSON" type="application/json">
{
    "jcr":{
        "year": "2017",
        "current_year": "2018",
        "journal": {
            "achre4": {
                "coden": "achre4",
                "title": "Accounts of Chemical Research",
                "citations": "67,004",
                "impact": "20.955",
                "articles": "275",
                "sort": "A"
            },
            "aabmcb": {
                "coden": "aabmcb",
                "title": "ACS Applied Bio Materials -New in 2018",
                "citations": "",
                "impact": "",
                "articles": "",
                "sort": "A" 
            },
            "aaemcq": {
                "coden": "aaemcq",
                "title": "ACS Applied Energy Materials",
                "citations": "",
                "impact": "",
                "articles": "",
                "sort": "A"             
            },
            "aamick": {
                "coden": "aamick",
                "title": "ACS Applied Materials & Interfaces",
                "citations": "123,233",
                "impact": "8.097",
                "articles": "4,862",
                "sort": "A"
            },
            "aanmf6": {
                "coden": "aanmf6",
                "title": "ACS Applied Nano Materials",
                "citations": "",
                "impact": "",
                "articles": "",
                "sort": "A" 
            },
            "abseba": {
                "coden": "abseba",
                "title": "ACS Biomaterials Science & Engineering",
                "citations": "2,048",
                "impact": "4.432",
                "articles": "360",
                "dart": "biomaterials_engineering",
                "sort": "A"
            },
            "accacs": {
                "coden": "accacs",
                "title": "ACS Catalysis",
                "citations": "39,650",
                "impact": "11.384",
                "articles": "994",
                "sort": "A"
            },
            "acscii": {
                "coden": "acscii",
                "title": "ACS Central Science",
                "citations": "2,106",
                "impact": "11.228",
                "articles": "143",
                "sort": "A"
            },
            "acbcct": {
                "coden": "acbcct",
                "title": "ACS Chemical Biology",
                "citations": "10,139",
                "impact": "4.592",
                "articles": "352",
                "sort": "A"
            },
            "acncdm": {
                "coden": "acncdm",
                "title": "ACS Chemical Neuroscience",
                "citations": "4,336",
                "impact": "4.211",
                "articles": "265",
                "sort": "A"
            },
            "acsccc": {
                "coden": "acsccc",
                "title": "ACS Combinatorial Science",
                "citations": "1,668",
                "impact": "3.500",
                "articles": "84",
                "sort": "A",
                    "history": [
                    "jcchff"
                ]
            },
            "jcchff": {
                "coden": "jcchff",
                "title": "Journal of Combinatorial Chemistry",
                "sort": "A",
                "legacy": true
            },
            "aesccq": {
                "coden": "aesccq",
                "title": "ACS Earth and Space Chemistry",
                "citations": "",
                "impact": "",
                "articles": "",
                "sort": "A" 
            },
            "eeeee": {
                "coden": "eeeee",
                "title": "ACS Editors' Choice",
                "dart": "editors_choice",
                "hidden": true,
                "sort": "A"
            },
            "aelccp": {
                "coden": "aelccp",
                "title": "ACS Energy Letters",
                "citations": "3,282",
                "impact": "12.277",
                "articles": "358",
                "sort": "A" 
            },
            "aidcbc": {
                "coden": "aidcbc",
                "title": "ACS Infectious Diseases",
                "citations": "749",
                "impact": "4.325",
                "articles": "88",
                "dart": "infectious_diseases",
                "sort": "A"
            },
            "amlccd": {
                "coden": "amlccd",
                "title": "ACS Macro Letters",
                "citations": "8,551",
                "impact": "6.131",
                "articles": "267",
                "sort": "A"
            },
            "amclct": {
                "coden": "amclct",
                "title": "ACS Medicinal Chemistry Letters",
                "citations": "4,851",
                "impact": "3.794",
                "articles": "220",
                "sort": "A"
            },
            "ancac3": {
                "coden": "ancac3",
                "title": "ACS Nano",
                "citations": "134,596",
                "impact": "13.709",
                "articles": "1,325",
                "sort": "A"
            },
            "acsodf": {
                "coden": "acsodf",
                "title": "ACS Omega",
                "sort": "A"
            },
            "aptsfn": {
                "coden": "aptsfn",
                "title": "ACS Pharmacology & Translational Science - New in 2018",
                "citations": "",
                "impact": "",
                "articles": "",
                "sort": "A"     
            },
            "apchd5": {
                "coden": "apchd5",
                "title": "ACS Photonics",
                "citations": "5,823",
                "impact": "6.880",
                "articles": "399",
                "dart": "photonics",
                "sort": "A"
            },
            "ascefj": {
                "coden": "ascefj",
                "title": "ACS Sensors",
                "citations": "1,408",
                "impact": "5.711",
                "articles": "239",
                "dart": "sensors",
                "sort": "A"
            },
            "ascecg": {
                "coden": "ascecg",
                "title": "ACS Sustainable Chemistry & Engineering",
                "citations": "12,770",
                "impact": "6.140",
                "articles": "1,281",
                "sort": "A"
            },
            "asbcd6": {
                "coden": "asbcd6",
                "title": "ACS Synthetic Biology",
                "citations": "3,112",
                "impact": "5.316",
                "articles": "242",
                "sort": "A"
            },
            "ancham": {
                "coden": "ancham",
                "title": "Analytical Chemistry",
                "citations": "123,665",
                "impact": "6.042",
                "articles": "1,788",
                "sort": "A",
                "history": [
                    "ancham.1"
                ]
            },
            "ancham.1": {
                "coden": "ancham",
                "title": "I&EC Analytical Edition",
                "sort": "A",
                "legacy": true
            },
            "bichaw": {
                "coden": "bichaw",
                "title": "Biochemistry",
                "citations": "76,552",
                "impact": "2.997",
                "articles": "643",
                "sort": "B"
            },
            "bcches": {
                "coden": "bcches",
                "title": "Bioconjugate Chemistry",
                "citations": "15,194",
                "impact": "4.485",
                "articles": "320",
                "sort": "B"
            },
            "bomaf6": {
                "coden": "bomaf6",
                "title": "Biomacromolecules",
                "citations": "36,807",
                "impact": "5.738",
                "articles": "432",
                "sort": "B"
            },
            "bipret": {
                "coden": "bipret",
                "title": "Biotechnology Progress",
                "sort": "B"
            },
            "cenear": {
                "coden": "cenear",
                "title": "C&EN Archives",
                "dart": "ce_n_archives",
                "sort": "C",
                "hidden": true
            },
            "crtoec": {
                "coden": "crtoec",
                "title": "Chemical Research in Toxicology",
                "citations": "12,692",
                "impact": "3.432",
                "articles": "191",
                "sort": "C"
            },
            "chreay": {
                "coden": "chreay",
                "title": "Chemical Reviews",
                "citations": "174,920",
                "impact": "52.613",
                "articles": "261",
                "sort": "C"
            },
            "cmatex": {
                "coden": "cmatex",
                "title": "Chemistry of Materials",
                "citations": "100,174",
                "impact": "9.890",
                "articles": "1,128",
                "sort": "C"
            },
            "cgdefu": {
                "coden": "cgdefu",
                "title": "Crystal Growth & Design",
                "citations": "28,165",
                "impact": "3.972",
                "articles": "769",
                "sort": "C"
            },
            "enfuem": {
                "coden": "enfuem",
                "title": "Energy & Fuels",
                "citations": "39,505",
                "impact": "3.024",
                "articles": "1,458",
                "sort": "E"
            },
            "esthag": {
                "coden": "esthag",
                "title": "Environmental Science & Technology",
                "citations": "156,556",
                "impact": "6.653",
                "articles": "1,529",
                "sort": "E"
            },
            "estlcu": {
                "coden": "estlcu",
                "title": "Environmental Science & Technology Letters",
                "citations": "1,660",
                "impact": "5.869",
                "articles": "93",
                "sort": "E"
            },
            "iechad": {
                "coden": "iechad",
                "title": "Industrial & Engineering Chemistry",
                "dart": "industrial_engineering_chemistry",
                "sort": "I"
            },
            "ieachad.1": {
                "coden": "iechad.1",
                "title": "Journal of Industrial & Engineering Chemistry",
                "sort": "I",
                "legacy": true
            },
            "iecred": {
                "coden": "iecred",
                "title": "Industrial & Engineering Chemistry Research",
                "citations": "67,598",
                "impact": "3.141",
                "articles": "1,451",
                "sort": "I"
            },
            "iepdaw": {
                "coden": "iepdaw",
                "title": "I&EC Process Design and Development",
                "sort": "I",
                "legacy": true
            },
            "iecfa7": {
                "coden": "iecfa7",
                "title": "I&EC Fundamentals",
                "sort": "I",
                "legacy": true
            },
            "iepra6": {
                "coden": "iepra6",
                "title": "Product Research & Development",
                "sort": "I",
                "legacy": true
            },
            "iepra6.1": {
                "coden": "iepra6.1",
                "title": "Product R&D",
                "sort": "I",
                "legacy": true
            },
            "iepra6.2": {
                "coden": "iepra6.2",
                "title": "I&EC Product Research and Development",
                "sort": "I",
                "legacy": true
            },
            "inocaj": {
                "coden": "inocaj",
                "title": "Inorganic Chemistry",
                "citations": "92,336",
                "impact": "4.700",
                "articles": "1,634",
                "sort": "I"
            },
            "jacsat": {
                "coden": "jacsat",
                "title": "Journal of the American Chemical Society",
                "citations": "533,512",
                "impact": "14.357",
                "articles": "2,633",
                "sort": "J"
            },
            "jafcau": {
                "coden": "jafcau",
                "title": "Journal of Agricultural and Food Chemistry",
                "citations": "103,329",
                "impact": "3.412",
                "articles": "1,249",
                "sort": "J"
            },
            "jceaax": {
                "coden": "jceaax",
                "title": "Journal of Chemical & Engineering Data",
                "citations": "20,894",
                "impact": "2.196",
                "articles": "486",
                "sort": "J",
                "history": [
                    "jceaax.1"
                ]
            },
            "jceaax.1": {
                "coden": "jceaax.1",
                "title": "I&EC Chemical & Engineering Data Series",
                "sort": "J",
                "legacy": true
            },
            "jceda8": {
                "coden": "jceda8",
                "title": "Journal of Chemical Education",
                "citations": "10,764",
                "impact": "1.758",
                "articles": "327",
                "sort": "J"
            },
            "jcisd8": {
                "coden": "jcisd8",
                "title": "Journal of Chemical Information and Modeling",
                "citations": "14,365",
                "impact": "3.804",
                "articles": "279",
                "sort": "J",
                "history": [
                    "jcisd8.1",
                    "jcisd8.2"
                ]
            },
            "jcisd8.1": {
                "coden": "jcisd8",
                "title": "Journal of Chemical Documentation",
                "sort": "J",
                "legacy": true
            },
            "jcisd8.2": {
                "coden": "jcisd8",
                "title": "Journal of Chemical Information and Computer Sciences",
                "sort": "J",
                "legacy": true
            },
            "jctcce": {
                "coden": "jctcce",
                "title": "Journal of Chemical Theory and Computation",
                "citations": "27,284",
                "impact": "5.399",
                "articles": "552",
                "sort": "J"
            },
            "jmcmar": {
                "coden": "jmcmar",
                "title": "Journal of Medicinal Chemistry",
                "citations": "69,725",
                "impact": "6.253",
                "articles": "679",
                "sort": "J"
            },
            "jnprdf": {
                "coden": "jnprdf",
                "title": "Journal of Natural Products",
                "citations": "24,905",
                "impact": "3.885",
                "articles": "419",
                "sort": "J"
            },
            "joceah": {
                "coden": "joceah",
                "title": "The Journal of Organic Chemistry",
                "citations":"100,091",
                "impact": "4.805",
                "articles": "1,467",
                "sort": "J"
            },
            "jpcafh": {
                "coden": "jpcafh",
                "title": "The Journal of Physical Chemistry A",
                "citations": "59,102",
                "impact": "2.836",
                "articles": "1,003",
                "sort": "J"
            },
            "jpcbfk": {
                "coden": "jpcbfk",
                "title": "The Journal of Physical Chemistry B",
                "citations": "113,923",
                "impact": "3.146",
                "articles": "1,138",
                "sort": "J"
            },
            "jpccck": {
                "coden": "jpccck",
                "title": "The Journal of Physical Chemistry C",
                "citations":"142,502",
                "impact": "4.484",
                "articles": "3,127",
                "sort": "J",
                "history":[
                    "jpchax",
                    "jpchax.1"
                ]  
            },
            "jpchax": {
                "coden": "jpchax",
                "title": "The Journal of Physical Chemistry",
                "sort": "J",
                "legacy": true
            },
            "jpchax.1": {
                "coden": "jpchax.1",
                "title": "The Journal of Physical and Colloid Chemistry",
                "sort": "J",
                "legacy": true
            },
            "jpclcd": {
                "coden": "jpclcd",
                "title": "The Journal of Physical Chemistry Letters",
                "citations": "39,275",
                "impact": "8.709",
                "articles": "951",
                "sort": "J"
            },
            "jprobs": {
                "coden": "jprobs",
                "title": "Journal of Proteome Research",
                "citations": "21,459",
                "impact": "3.950",
                "articles": "394",
                "sort": "J"
            },
            "langd5": {
                "coden": "langd5",
                "title": "Langmuir",
                "citations": "118,255",
                "impact": "3.789",
                "articles": "1,612",
                "sort": "L"
            },
            "mamobx": {
                "coden": "mamobx",
                "title": "Macromolecules",
                "citations": "105,933",
                "impact": "5.914",
                "articles": "966",
                "sort": "M"
            },
            "mpohbp": {
                "coden": "mpohbp",
                "title": "Molecular Pharmaceutics",
                "citations": "15,754",
                "impact": "4.556",
                "articles": "435",
                "sort": "M"
            },
            "nalefd": {
                "coden": "nalefd",
                "title": "Nano Letters",
                "citations": "153,533",
                "impact": "12.080",
                "articles": "1,136",
                "sort": "N"
            },
            "orlef7": {
                "coden": "orlef7",
                "title": "Organic Letters",
                "citations": "95,762",
                "impact": "6.492",
                "articles": "1,694",
                "sort": "O"
            },
            "oprdfk": {
                "coden": "oprdfk",
                "title": "Organic Process Research & Development",
                "citations": "6,475",
                "impact": "3.584",
                "articles": "223",
                "sort": "O"
            },
            "orgnd7": {
                "coden": "orgnd7",
                "title": "Organometallics",
                "citations": "40,867",
                "impact": "4.051",
                "articles": "582",
                "sort": "O"
            }
        }
    }
}
</script>

<script type="text/javascript">
function hideShow(link) {
    var toggleHideShow = $(link).next('div.category-data-jcr');
    var toggleExpandButton = $(link).children(".expandButton");

    if(toggleHideShow.hasClass('selected')) {
        toggleHideShow.removeClass('selected');
        toggleExpandButton.removeClass('selected');
    }
    else {
        toggleHideShow.addClass('selected');
        toggleExpandButton.addClass('selected');
        $('html, body').animate({scrollTop: $(link).offset().top}, 1000);
    }
}

function categorySelect(link) {
    var category = $(link).attr('href');
    var highlightColor = $(category + " .category-header").css('background-color');
    var categoryHeader = $(category + " .category-header");
    var toggleHideShow = categoryHeader.next('div.category-data-jcr');
    var toggleExpandButton = categoryHeader.children(".expandButton");
  
    $('html, body').animate({scrollTop: $(category).offset().top}, 1000, function() {
        if (!(toggleHideShow.hasClass("selected"))) {
            toggleHideShow.addClass('selected');
            toggleExpandButton.addClass('selected');
            $('html, body').animate({scrollTop: categoryHeader.offset().top}, 1200);
        }
    });
}

function JCRtable(journals, divID) {
    var data = JSON.parse($('#jcrJSON').html());
    var jcrData = [];
    var items = [];
    var journalList = [];
    jcrData = data["jcr"]["journal"];
    journalList = journals.replace(/ /g,'').split(",");
    var categoryTable = $("<table class='jcr-table'>");
    categoryTable.append("<tr><th class='jcr-table-title'>Journal Title</th><th class='jcr-table-if'>Impact<br />Factor*</th><th class='jcr-table-articles'>Total Articles<br />Published*</th><th class='jcr-table-citations'>Total<br />Citations*</th></tr>");
    // categoryTable.append("<tr><th class='jcr-table-title'>Journal Title</th><th class='jcr-table-google'><a href='https://scholar.google.com/citations?view_op=top_venues&hl=en&vq=chm'>Google Scholar<br />h5-index</a>**</th><th class='jcr-table-if'>Impact<br />Factor*</th><th class='jcr-table-articles'>Total Articles<br />Published*</th><th class='jcr-table-citations'>Total<br />Citations*</th></tr>");
    for(i=0; i<journalList.length; i++) {
        var categoryTableRow = $("<tr>");
        items[i] = jcrData[journalList[i]];
            if(items[i] != undefined) {
                categoryTableRow.append($("<td class='jcr-table-title'><a href='http://pubs.acs.org/journal/"  + items[i]['coden'] + "'>" + items[i]['title'] +"</a></td>"));
                if(items[i]['new'] != undefined) {
                    categoryTableRow.children('td.jcr-table-title').append(" <em>" + items[i]['new'] + "</em>");
                }
                // if(items[i]['googleH5'] != undefined) {
                //  categoryTableRow.append($("<td class='jcr-table-google'>" + items[i]['googleH5'] +"</td>"));
                // }
                // else if (items[i]['googleH5'] == undefined) {
                //  categoryTableRow.append($("<td class='jcr-table-google'></td>"));
                // }
                categoryTableRow.append($("<td class='jcr-table-if'>"  + items[i]['impact'] +"</td><td class='jcr-table-articles'>" + items[i]['articles'] +"</td><td class='jcr-table-citations'>" + items[i]['citations'] +"</td>"));
                categoryTable.append(categoryTableRow);
            }
    }
    $("#" + divID).append(categoryTable);
}

$(function(){
    var data = JSON.parse($('#jcrJSON').html());
    var jcrData = [];
    var journalList = [];
    var journalSortList = "";
    jcrData = data["jcr"]["journal"];

    for(keys in jcrData) {
        if(jcrData[keys]["impact"]) {
            journalList.push(jcrData[keys]);
        }
    }

    // move 'The' out of the way for sorting
    journalList.forEach(function(item) {
        if (item["title"].indexOf("The ") > -1) {
            item["title"] = item["title"].split("The ")[1] + ", The";
        }
        item["title"] = item["title"].toLowerCase();
    });

    // sort list alphabetically by full title 
    journalList.sort(function(a, b){
        if(a["title"] < b["title"]) return -1;
        if(a["title"] > b["title"]) return 1;
        return 0;
    });

    // create list string of sorted journal titles
    journalList.forEach(function(item) {
        journalSortList += item["coden"] + ", ";
    });

    // create A-Z journal listing
    JCRtable(journalSortList, "a-z-listing");

    $("#tab-section .tab").click(function(e) {
        e.preventDefault();
        selection = this.id.split("tab-")[1];
        $("#tab-section .tab").removeClass("selected");
        $(".content-section").removeClass("selected");
        $("#tab-" + selection).addClass("selected");
        $("#" + selection).addClass("selected");
    });

    // footer update
    $("#jcr-year").text(data["jcr"]["year"]);
    $("#current-year").text(data["jcr"]["current_year"]);
    $("#copyright").html("Copyright &copy; " + data["jcr"]["current_year"]);
});
</script>


<style type="text/css">
    #bg-upper {
    width: 1024px;
    height: 498px;
    padding-bottom:0px;
    background: url("images/jcr-hero.jpg") no-repeat;
    margin-bottom: -20px;
}
    
    .colors{
        width:1024px;
        height:18px;
        background: url("images/colors.jpg") no-repeat;
    }
    
    .category-header .expandButton {
    height: 60px;
    width: 115px;
    background: url("images/button-expand.png") no-repeat;
    float: right;
    margin: 0;
  }

  .category-header .expandButton.selected {
    background: url("images/button-close.png") no-repeat;
    margin: 5px 5px 0 0;
  }
  
  #category-list .category-icon-space:hover {
    background: url("images/icon-hover.png") no-repeat;
}
    
</style>

<link href='https://fonts.googleapis.com/css?family=Raleway:400,300italic,700' rel='stylesheet' type='text/css'>


<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/3.0.3/cookieconsent.min.css">
<script src="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/3.0.3/cookieconsent.min.js"></script>
<script>
window.addEventListener("load", function(){
window.cookieconsent.initialise({
  "palette": {
    "popup": {
      "background": "#0039a6",
      "text": "#ffffff"
    },
    "button": {
      "background": "#fdc82f",
      "text": "#000000"
    }
  },
  "content": {
    "message": " This website uses cookies to ensure you get the best user experience. By continuing to use this website we assume you are happy with this. Read more in our privacy policy.",
    "dismiss": "Close and don't show again",
    "link": " Read more in our privacy policy ",
    "href": "https://www.acs.org/content/acs/en/privacy.html"
  }
})});
</script>
<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/3.0.3/cookieconsent.min.css">
<script src="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/3.0.3/cookieconsent.min.js"></script>
<script>
window.addEventListener("load", function(){
window.cookieconsent.initialise({
  "palette": {
    "popup": {
      "background": "#0039a6",
      "text": "#ffffff"
    },
    "button": {
      "background": "#fdc82f",
      "text": "#000000"
    }
  },
  "content": {
    "message": " This website uses cookies to ensure you get the best user experience. By continuing to use this website we assume you are happy with this. Read more in our privacy policy.",
    "dismiss": "Close and don't show again",
    "link": " Read more in our privacy policy ",
    "href": "https://www.acs.org/content/acs/en/privacy.html"
  }
})});
</script>
</head>

<body>
<header id="header-big">
            <div id="header-big-bar">
                <div class="container +wrapper">
                    <nav id="utility-nav-big">
                        <ul>
                            <li><a class="active" href="http://www.acs.org/content/acs/en.html" target="_blank">ACS</a></li>
                            <li><a href="http://pubs.acs.org/" target="_blank">Publications</a></li>
                            <li><a href="http://cen.acs.org/index.html" target="_blank">C&amp;EN</a></li>
                            <li><a href="http://www.cas.org/" target="_blank">CAS</a></li>
                            <li><a href="http://acsinthenews.org/" target="_blank">ACS In The News</a></li>
                        </ul>
                    </nav>
                    <a class="e-alerts" href="http://pubs.acs.org/page/follow.html#e-alerts" target="_blank">
                        Get updated with e-Alerts
                        <span class="envelope"><img src="images/icon-ealerts.png" alt="ACS E-Alerts"></span>
                    </a>
                </div>
            </div>
            <div class="big-icon">
                <img src="images/logo-icon-big.png" alt="ACS Axial: Your Bond With Chemistry">
            </div>
            <div id="header-big-main">
                <div class="left">
                    <a class="logo" href="/">
                        <img src="images/logo-shadow.png" alt="ACS Publications">
                        <img class="headline" src="images/logo-headline.png" alt="ACS Axial: Your Bond With Chemistry">
                    </a>
                </div>
                <div class="right">
                    <img src="images/acs-publications.png" alt="ACS Publications">
                </div>
            </div>
            <div id="header-big-bottom">

	            <div class="container">
	            
	            	 <nav id="main-nav-big">
                        <ul>
                            <li><a class="has-dropdown" href="/category/journal">Journal</a></li>
                            <li><a class="has-dropdown" href="/category/Topic">Topic</a></li>
                            <li><a href="/category/career">Career</a></li>
                            <li><a class="has-dropdown" href="/category/content">Content</a></li>
                            <li><a class="has-dropdown" href="/category/career/librarian">Librarian</a></li>
                            <li><a class="has-dropdown" href="/axial-acs-blog">About</a></li>
                        </ul>
                    </nav>
                 
                </div>
            </div>
        </header>
<div id="content">

    <div id="header-jcr">
        <a href="http://pubs.acs.org?elqTrackId=dd5e9660816042dd9c3ae9390356d2b2" title="ACS Publications"><img src="http://images.acspubs.org/EloquaImages/clients/AmericanChemicalSociety/%7B75b5f970-6073-4031-bfac-1480632d5db1%7D_acs-pubs-logo-small.png" id="logo" alt="ACS Publications"></a>
            
        <!--<a id="header-alert" href="http://journalstars.acs.org?elqTrackId=206fb731e4a84715bcfe78f6646c8dda" title="Speak Out For Your Science">
            <img src="http://images.acspubs.org/EloquaImages/clients/AmericanChemicalSociety/%7B18176250-2634-4f69-97fd-e3cc90477b60%7D_speak-out-button.png" alt="Speak Out For Your Science">
        </a>-->
    </div>
    
    <div id="hero">
        <div id="bg-upper">
            <div id="header-text">
                <h3>2017 Journal Citation Reports</h3>
                <h1>Strength</h1>
                <h2>in numbers</h2>
                <br class="clear">
                <p>Thanks to our global community of authors, reviewers, and editors for your vital contributions and the strong results achieved in total citations, Impact Factor, and influence.</p>
            </div>
            <!--<div id="header-text-right">
                <div id="rocket">
                    <img src="http://images.acspubs.org/EloquaImages/clients/AmericanChemicalSociety/%7Bd8684c5d-b877-4d82-9f1f-e571c5beca08%7D_rocket.png">
                </div>
            </div>-->
        </div>
        <div class="colors"></div>
        <div id="bg-lower">
            <div id="planets">
                <a href="http://pubs.acs.org/journal/chreay?utm_source=Axial&utm_medium=Partner&utm_campaign=JCR2018" title="Chemical Reviews">
                    <div id="planet-chemreviews" class="planet">
                        <div class="planets-title">Chemical Reviews</div>
                        <div class="planets-impactfactor">52.613</div>
                        <div class="planets-impact">Impact Factor</div>
                    </div>
                </a>
                <a href="https://pubsdc3.acs.org/journal/achre4?utm_source=Axial&utm_medium=Partner&utm_campaign=JCR2018" title="Account of Chemical Research">
                    <div id="planet-nano" class="planet">
                        <div class="planets-title">Accounts of Chemical<br>Research</div>
                        <div class="planets-impactfactor">20.955</div>
                        <div class="planets-impact">Impact Factor</div>
                    </div>
                </a>
                <a href="http://pubs.acs.org/journal/jacsat?utm_source=Axial&utm_medium=Partner&utm_campaign=JCR2018" title="Journal of the American Chemical Society">
                    <div id="planet-jacs" class="planet">
                        <div class="planets-title">JACS</div>
                        <div class="planets-impactfactor">14.357</div>
                        <div class="planets-impact">Impact Factor</div>
                    </div>
                </a>
                  <a href="http://pubs.acs.org/journal/acscii?utm_source=Axial&utm_medium=Partner&utm_campaign=JCR2018" title="ACS Central Science">
                  <div id="planet-acscii" class="planet">
                        <div class="planets-title">ACS Central Science</div>
                        <div class="planets-impactfactor">11.228</div>
                        <div class="planets-impact">Impact Factor</div>
                  </div>
                </a>
                <br class="clear">
                <a href="http://pubs.acs.org/journal/aelccp?utm_source=Axial&utm_medium=Partner&utm_campaign=JCR2018" title="ACS Energy Letters">
                    <div id="planet-catalysis" class="planet">
                        <div class="planets-title">ACS Energy Letters</div>
                        <div class="planets-impactfactor">12.277</div>
                        <div class="planets-impact">Impact Factor</div>
                    </div>
                </a>
                <a href="http://pubs.acs.org/journal/aamick?utm_source=Axial&utm_medium=Partner&utm_campaign=JCR2018" title="ACS Applied Materials & Interfaces">
                    <div id="planet-materials" class="planet">
                        <div class="planets-title">ACS Applied Materials<br>&amp; Interfaces</div>
                        <div class="planets-impactfactor">8.097</div>
                        <div class="planets-impact">Impact Factor</div>
                    </div>
                </a>
                <a href="http://pubs.acs.org/journal/ascefj?utm_source=Axial&utm_medium=Partner&utm_campaign=JCR2018" title="ACS Sensors">
                    <div id="planet-jpcl" class="planet">
                        <div class="planets-title">ACS Sensors</div>
                        <div class="planets-impactfactor">5.711</div>
                        <div class="planets-impact">Impact Factor</div>
                    </div>
                </a>
                <a href="https://pubs.acs.org/journal/ancac3?utm_source=Axial&utm_medium=Partner&utm_campaign=JCR2018" title="ACS Nano">
                    <div id="planet-photonics" class="planet">
                        <div class="planets-title">ACS Nano</div>
                        <div class="planets-impactfactor">13.709</div>
                        <div class="planets-impact">Impact Factor</div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <br class="clear">
    
     <div id="chart">
        <div id="chart-left">
            <p>Articles published by ACS journals in the core chemistry categories in 2017 have the most total cites and cites per article</p>
        </div>
        <div id="chart-right">
            <img src="images/chart-2017.jpg">
        </div>
        <br class="clear">
    </div>


    <br class="clear">

    <div id="body-section">
        <h2>Show me</h2>
        <div id="tab-section">
            <a class="tab selected" id="tab-category-section" href="#">Journal Categories</a>
            <a class="tab" id="tab-a-z-listing" href="#">Journals A-Z</a>
        </div>

        <div id="category-section" class="content-section selected">
            <div id="category-list">
                <div class="category-icon-space">
                    <a class="category-icon" href="#category1" onclick="categorySelect(this); return false;"><img src="images/icon-analytical.png"></a>
                    <a class="category-link" href="#category1" onclick="categorySelect(this); return false;">ANALYTICAL</a>
                </div>
                <div class="category-icon-space">
                    <a class="category-icon" href="#category2" onclick="categorySelect(this); return false;"><img src="images/icon-applied.png"></a>
                    <a class="category-link" href="#category2" onclick="categorySelect(this); return false;">APPLIED</a>
                </div>
                <div class="category-icon-space">
                    <a class="category-icon" href="#category3" onclick="categorySelect(this); return false;"><img src="images/icon-biological.png"></a>
                    <a class="category-link" href="#category3" onclick="categorySelect(this); return false;">BIOLOGICAL</a>
                </div>
                <div class="category-icon-space">
                    <a class="category-icon" href="#category4" onclick="categorySelect(this); return false;"><img src="images/icon-materials.png"></a>
                    <a class="category-link" href="#category4" onclick="categorySelect(this); return false;">MATERIALS<br> SCIENCE AND<br> ENGINEERING</a>
                </div>
                <div class="category-icon-space">
                    <a class="category-icon" href="#category5" onclick="categorySelect(this); return false;"><img src="images/icon-organic.png"></a>
                    <a class="category-link" href="#category5" onclick="categorySelect(this); return false;">ORGANIC/<br>INORGANIC</a>
                </div>
                <div class="category-icon-space">
                    <a class="category-icon" href="#category6" onclick="categorySelect(this); return false;"><img src="images/icon-physical.png"></a>
                    <a class="category-link" href="#category6" onclick="categorySelect(this); return false;">PHYSICAL</a>
                </div>
            </div>

            <div class="clear">&nbsp;</div>
            
            <div id="category-data">
                <div id="category1">
                    <a href="#" class="category-header category-color-1" onclick="hideShow(this); return false;"><img src="images/icon-analytical.png" class="small-icon"> <span>ANALYTICAL</span> <div class="expandButton"></div></a> 
                    <div class="category-data-jcr">
                        <div id="category1table"></div>
                        <script type="text/javascript">
                            JCRtable('achre4, acscii, ascefj, ancham, chreay, esthag, estlcu, jacsat, jafcau, jceda8, jprobs', 'category1table');
                        </script>
                        
                    </div>
                </div>

                <div id="category2">
                    <a href="#" class="category-header category-color-2" onclick="hideShow(this); return false;"><img src="images/icon-applied.png" class="small-icon"> <span>APPLIED</span> <div class="expandButton"></div></a> 
                    <div class="category-data-jcr">
                        <div id="category2table"></div>
                        <script type="text/javascript">
                            JCRtable('aamick, abseba, acsccc, aelccp, aidcbc, amclct, ascefj, ascecg, asbcd6, ancham, crtoec, cgdefu, enfuem, esthag, estlcu, iecred, jafcau, jceaax, jceda8, jcisd8, jctcce, jmcmar, jpcafh, jpcbfk, jpccck, jpclcd, jprobs, mpohbp, oprdfk', 'category2table');
                        </script>
                       
                    </div>
                </div>

                <div id="category3">
                    <a href="#" class="category-header category-color-3" onclick="hideShow(this); return false;"><img src="images/icon-biological.png" class="small-icon"> <span>BIOLOGICAL</span> <div class="expandButton"></div></a> 
                    <div class="category-data-jcr">
                        <div id="category3table"></div>
                        <script type="text/javascript">
                            JCRtable('achre4, abseba, accacs, acscii, acbcct, acncdm, aidcbc, amclct, ascefj, asbcd6, bichaw, bcches, bomaf6, chreay, crtoec, jacsat, jafcau, jctcce, jmcmar, jnprdf, jpcbfk, jpclcd, jprobs, mpohbp', 'category3table');
                        </script>
                      
                    </div>
                </div>

                <div id="category4">
                    <a href="#" class="category-header category-color-4" onclick="hideShow(this); return false;"><img src="images/icon-materials.png" class="small-icon"> <span>MATERIALS SCIENCE &amp; ENGINEERING</span> <div class="expandButton"></div></a> 
                    <div class="category-data-jcr">
                        <div id="category4table"></div>
                        <script type="text/javascript">
                            JCRtable('achre4, aamick, abseba, accacs, acscii, aelccp, amlccd, ancac3, apchd5, ascecg, bcches, bomaf6, chreay, cmatex, cgdefu, enfuem, iecred, inocaj, jacsat, jceaax, jpccck, jpclcd, langd5, mamobx, nalefd', 'category4table');
                        </script>
                        
                    </div>
                </div>

                <div id="category5">
                    <a href="#" class="category-header category-color-5" onclick="hideShow(this); return false;"><img src="images/icon-organic.png" class="small-icon"> <span>ORGANIC/INORGANIC</span> <div class="expandButton"></div></a> 
                    <div class="category-data-jcr">
                        <div id="category5table"></div>
                        <script type="text/javascript">
                            JCRtable('achre4, accacs, acscii, acsccc, amclct, bcches, chreay, crtoec, inocaj, jacsat, jmcmar, jnprdf, joceah, mpohbp, orlef7, oprdfk, orgnd7', 'category5table');
                        </script>
                        
                    </div>
                </div>

                <div id="category6">
                    <a href="#" class="category-header category-color-6" onclick="hideShow(this); return false;"><img src="images/icon-physical.png" class="small-icon"> <span>PHYSICAL</span> <div class="expandButton"></div></a> 
                    <div class="category-data-jcr">
                        <div id="category6table"></div>
                        <script type="text/javascript">
                            JCRtable('achre4, acscii, aelccp, ancac3, apchd5, chreay, enfuem, iecred, jacsat, jceaax, jcisd8, jctcce, jpcafh, jpcbfk, jpccck, jpclcd, nalefd', 'category6table');
                        </script>
                        
                    </div>
                </div>
            </div>
        </div>

        <div id="a-z-listing" class="content-section"></div>
    </div>
    
    <div class="clear">&nbsp;</div>
    
   

    <div id="legend">
        <p style="display: none;"><strong>(*) (**) Legend:</strong></p>
        <p style="display: none;"><strong>** <a href="https://scholar.google.com/intl/en/scholar/metrics.html#metrics">h-Index</a></strong> &mdash; The largest number h such that at least h articles in that publication were cited at least h times each. h5-Index takes into account only those articles that were published in the last five complete calendar years.</p>
        <p>2017 Journal Citation Reports&reg; (Clarivate Analytics, 2018)</p>
        <p><strong>* <a href="http://wokinfo.com/essays/impact-factor/">Impact Factor</a></strong> &mdash; A measure of the frequency with which the "average article" in a journal has been cited in a particular year or period, calculated by the number of citations in the Impact Factor year to content published in the previous two years, divided by the total number of peer-reviewed articles published during the two-year period prior to the Impact Factor year.</p>
    </div>

    <div id="footer">
        <hr>
        
        <br class="clear">
        
        <div id="logo">
           <a href="http://pubs.acs.org?utm_source=Axial&utm_medium=Partner&utm_campaign=JCR2018" title="ACS Publications"><img src="http://images.acspubs.org/EloquaImages/clients/AmericanChemicalSociety/{74edb70c-6cd8-4285-820a-52c6f8fa4195}_acs-pubs-logo.png"></a>
        </div>
        <div id="address">
            <p>Copyright &copy; 2017</p>
            <p><strong>American Chemical Society</strong> 1155 Sixteenth Street N.W. Washington, DC 20036</p>
        </div>
        
        <br class="clear">
    </div>

</div>

<div class="clear">&nbsp;</div>

</body>
</html>
